<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_demo' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '@1hZ/HIhl{o_?*N:`flY!aY>.D.>sXT>O,%tB/#&nR)1DG[pd%7<h6clnK#JSg]N' );
define( 'SECURE_AUTH_KEY',  'NiqUyO(r4Tp=c?!sb@2TnVoF M40vVO%EKF&oTKzBE<C&x-|9!9`Aa%tFw33@8f!' );
define( 'LOGGED_IN_KEY',    '`#rvfj-@<lFdSjXBXSdks7F7>B7#[$d:YIc-EU0%n9+f^o1skHm`Ii5~]aCRSc`H' );
define( 'NONCE_KEY',        '<z.-Y/S41/yW1XXjP.e^96c5.F}3g^M<BaI8n+s.rU4k*{vo+(<hqFvo>kXZo?~P' );
define( 'AUTH_SALT',        ',fAuFM)LPD)p9(|@{b<JAOO2t V<{f]g+`/b98(#t/x8s*Jm+8gzHzEk&W$t(C$F' );
define( 'SECURE_AUTH_SALT', 'Pv)a4<`}FO@Fdc|!E% (/2^4t<w5r~Pp9zIB|ea3{1pt?G@!U_@3~1IeZO`h<BLz' );
define( 'LOGGED_IN_SALT',   'k|0G1S{!&2Z2%@l8OC*PR3ove<HmY(Fp>?c&c()bb! 7!)]Cw,!vQ7e_/ 8`RTe+' );
define( 'NONCE_SALT',       'd0p:sgnng#o)=vh@sBP]SfY1UW,r&AK4mgHp *T3 Gv6_rYPG%AF>G?m+Xf~W{:,' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wpd_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );
define( 'WP_DEBUG_LOG', true );
define( 'WP_DEBUG_DISPLAY', false );
/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
